# Reply

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metadata** | [**[]ReplyMetadata**](reply_metadata.md) |  | [optional] [default to null]
**Links** | [**[]ReplyLinks**](reply_links.md) |  | [optional] [default to null]
**Items** | [**[]Wip**](wip.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

