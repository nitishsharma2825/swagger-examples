# Wip

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**WipIdentifier** | **string** |  | [optional] [default to null]
**CustomerIdentifier** | **string** |  | [optional] [default to null]
**AccountIdentifier** | **string** |  | [optional] [default to null]
**ActivityIdentifier** | **string** |  | [optional] [default to null]
**GivenName** | **string** |  | [optional] [default to null]
**FamilyName** | **string** |  | [optional] [default to null]
**Email** | **string** |  | [optional] [default to null]
**Telephone** | **string** |  | [optional] [default to null]
**Status** | **string** |  | [optional] [default to null]
**MaxValue** | **string** |  | [optional] [default to null]
**Discount** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

