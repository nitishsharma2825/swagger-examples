# {{classname}}

All URIs are relative to *https://virtserver.swaggerhub.com/Nitish-ef2/onboarding-api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetAccountData**](OnboardingApi.md#GetAccountData) | **Get** /wip/{identifier}/account | Use this to get the account data for this WIP recxord
[**GetActivityData**](OnboardingApi.md#GetActivityData) | **Get** /wip/{identifier}/activity | Use this to get the activity data for this WIP recxord
[**GetCustomerData**](OnboardingApi.md#GetCustomerData) | **Get** /wip/{identifier}/customer | Use this to get the customer data for this WIP record
[**GetStatus**](OnboardingApi.md#GetStatus) | **Get** /wip/{identifier}/status | Use this to get the status for this WIP recxord
[**Home**](OnboardingApi.md#Home) | **Get** / | Use this to retrieve the home page for the onboarding API
[**StartOnboarding**](OnboardingApi.md#StartOnboarding) | **Post** /start | Use this to start process of onboarding a customer
[**UpdateAccountData**](OnboardingApi.md#UpdateAccountData) | **Put** /wip/{identifier}/account | Use this to update the account data for this WIP record
[**UpdateActivityData**](OnboardingApi.md#UpdateActivityData) | **Put** /wip/{identifier}/activity | Use this to update the activity data for this WIP record
[**UpdateCustomerData**](OnboardingApi.md#UpdateCustomerData) | **Put** /wip/{identifier}/customer | Use this to update the customer data for this WIP record
[**UpdateStatus**](OnboardingApi.md#UpdateStatus) | **Put** /wip/{identifier}/status | Use this to update the status for this WIP record
[**WipItem**](OnboardingApi.md#WipItem) | **Get** /wip/{identifier} | Use this to return a single onboarding record
[**WipList**](OnboardingApi.md#WipList) | **Get** /wip | Use this to get a list of onboarding records

# **GetAccountData**
> Reply GetAccountData(ctx, identifier, optional)
Use this to get the account data for this WIP recxord

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **identifier** | **string**| record identifier | 
 **optional** | ***OnboardingApiGetAccountDataOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a OnboardingApiGetAccountDataOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **eTag** | **optional.String**| Conditional Read Header | 

### Return type

[**Reply**](reply.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/prag+json, application/json, application/problem+json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetActivityData**
> Reply GetActivityData(ctx, identifier, optional)
Use this to get the activity data for this WIP recxord

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **identifier** | **string**| record identifier | 
 **optional** | ***OnboardingApiGetActivityDataOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a OnboardingApiGetActivityDataOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **eTag** | **optional.String**| Conditional Read Header | 

### Return type

[**Reply**](reply.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/prag+json, application/json, application/problem+json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetCustomerData**
> Reply GetCustomerData(ctx, identifier, optional)
Use this to get the customer data for this WIP record

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **identifier** | **string**| record identifier | 
 **optional** | ***OnboardingApiGetCustomerDataOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a OnboardingApiGetCustomerDataOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **eTag** | **optional.String**| Conditional Read Header | 

### Return type

[**Reply**](reply.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/prag+json, application/json, application/problem+json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetStatus**
> Reply GetStatus(ctx, identifier, optional)
Use this to get the status for this WIP recxord

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **identifier** | **string**| record identifier | 
 **optional** | ***OnboardingApiGetStatusOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a OnboardingApiGetStatusOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **eTag** | **optional.String**| Conditional Read Header | 

### Return type

[**Reply**](reply.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/prag+json, application/json, application/problem+json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **Home**
> Reply Home(ctx, optional)
Use this to retrieve the home page for the onboarding API

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***OnboardingApiHomeOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a OnboardingApiHomeOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **eTag** | **optional.String**| Conditional Read Header | 

### Return type

[**Reply**](reply.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/prag+json, application/json, application/problem+json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **StartOnboarding**
> StartOnboarding(ctx, optional)
Use this to start process of onboarding a customer

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***OnboardingApiStartOnboardingOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a OnboardingApiStartOnboardingOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **identifier** | **optional.**|  | 
 **body** | [**optional.Interface of Start**](Start.md)|  | 
 **ifNoneMatch** | **optional.**| Conditional Create Header | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/problem+json, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **UpdateAccountData**
> Reply UpdateAccountData(ctx, identifier, optional)
Use this to update the account data for this WIP record

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **identifier** | **string**| record identifier | 
 **optional** | ***OnboardingApiUpdateAccountDataOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a OnboardingApiUpdateAccountDataOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **identifier** | **optional.**|  | 
 **body** | [**optional.Interface of Account**](Account.md)|  | 
 **ifMatch** | **optional.**| Conditional Update Header | 

### Return type

[**Reply**](reply.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/prag+json, application/json, application/problem+json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **UpdateActivityData**
> Reply UpdateActivityData(ctx, identifier, optional)
Use this to update the activity data for this WIP record

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **identifier** | **string**| record identifier | 
 **optional** | ***OnboardingApiUpdateActivityDataOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a OnboardingApiUpdateActivityDataOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **identifier** | **optional.**|  | 
 **body** | [**optional.Interface of Activity**](Activity.md)|  | 
 **ifMatch** | **optional.**| Conditional Update Header | 

### Return type

[**Reply**](reply.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/prag+json, application/json, application/problem+json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **UpdateCustomerData**
> Reply UpdateCustomerData(ctx, identifier, optional)
Use this to update the customer data for this WIP record

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **identifier** | **string**| record identifier | 
 **optional** | ***OnboardingApiUpdateCustomerDataOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a OnboardingApiUpdateCustomerDataOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **identifier** | **optional.**|  | 
 **givenName** | **optional.**|  | 
 **familyName** | **optional.**|  | 
 **body** | [**optional.Interface of Customer**](Customer.md)|  | 
 **ifMatch** | **optional.**| Conditional Update Header | 

### Return type

[**Reply**](reply.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/prag+json, application/json, application/problem+json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **UpdateStatus**
> Reply UpdateStatus(ctx, identifier, optional)
Use this to update the status for this WIP record

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **identifier** | **string**| record identifier | 
 **optional** | ***OnboardingApiUpdateStatusOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a OnboardingApiUpdateStatusOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **identifier** | **optional.**|  | 
 **status** | **optional.**|  | 
 **body** | [**optional.Interface of Status**](Status.md)|  | 

### Return type

[**Reply**](reply.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/prag+json, application/json, application/problem+json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **WipItem**
> Reply WipItem(ctx, identifier, optional)
Use this to return a single onboarding record

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **identifier** | **string**| record identifier | 
 **optional** | ***OnboardingApiWipItemOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a OnboardingApiWipItemOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **eTag** | **optional.String**| Conditional Read Header | 

### Return type

[**Reply**](reply.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/prag+json, application/json, application/problem+json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **WipList**
> Reply WipList(ctx, optional)
Use this to get a list of onboarding records

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***OnboardingApiWipListOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a OnboardingApiWipListOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **status** | **optional.String**| status flag | 
 **eTag** | **optional.String**| Conditional Read Header | 

### Return type

[**Reply**](reply.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/prag+json, application/json, application/problem+json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

