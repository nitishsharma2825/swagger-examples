# ReplyLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [optional] [default to null]
**Href** | **string** |  | [optional] [default to null]
**Title** | **string** |  | [optional] [default to null]
**Method** | **string** |  | [optional] [default to null]
**Properties** | [**[]ReplyProperties**](reply_properties.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

